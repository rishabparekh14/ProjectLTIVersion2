package com.lti.hackathon.exam.portal.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CandidateStatus")
public class CandidateTestStatus {

	@Id
	@GeneratedValue
	private int statusId;

	@Column(name = "emailAddress")
	private String emailAddress;

	@Column(name = "optionId")
	private int optionId;

	@Column(name = "stage")
	private int stage;

	@OneToOne(mappedBy = "candidateTestStatus", fetch = FetchType.EAGER)
	private OptionList optionList;

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public int getOptionId() {
		return optionId;
	}

	public void setOptionId(int optionId) {
		this.optionId = optionId;
	}

	public OptionList getOptionList() {
		return optionList;
	}

	public void setOptionList(OptionList optionList) {
		this.optionList = optionList;
	}

	public CandidateTestStatus() {

		// TODO Auto-generated constructor stub
	}

	public CandidateTestStatus(int statusId, String emailAddress, int optionId, int stage, OptionList optionList) {

		this.statusId = statusId;
		this.emailAddress = emailAddress;
		this.optionId = optionId;
		this.stage = stage;
		this.optionList = optionList;
	}

	public int getStatusId() {
		return statusId;
	}

	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}

	public int getStage() {
		return stage;
	}

	public void setStage(int stage) {
		this.stage = stage;
	}

}
