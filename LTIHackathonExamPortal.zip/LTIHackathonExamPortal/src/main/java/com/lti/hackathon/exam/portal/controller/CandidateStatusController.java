package com.lti.hackathon.exam.portal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.hackathon.exam.portal.entity.CandidateTestStatus;
import com.lti.hackathon.exam.portal.service.CandidateStatusService;

@RestController
@CrossOrigin
public class CandidateStatusController {

	@Autowired
	private CandidateStatusService candidateStatusService;

	@RequestMapping(path = "/getResult/{emailAddress}/{stage}", method = RequestMethod.GET)
	public long getResult(@PathVariable("emailAddress") String emailAddress, @PathVariable("stage") int stage) {
		long result = candidateStatusService.getScore(emailAddress, stage);

		return result;
	}

	@RequestMapping(path = "/submit", method = RequestMethod.POST)
	public String addCandidateAnswers(@RequestBody CandidateTestStatus candidateTestStatus) {
		String status = candidateStatusService.addCandidateAnswers(candidateTestStatus);
		System.out.println("Hello");
		return status;
	}
}
