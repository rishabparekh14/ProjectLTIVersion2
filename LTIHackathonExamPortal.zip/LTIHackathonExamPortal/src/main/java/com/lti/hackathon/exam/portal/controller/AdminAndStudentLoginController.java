package com.lti.hackathon.exam.portal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.hackathon.exam.portal.dto.LoginResult;
import com.lti.hackathon.exam.portal.entity.RegisterStudent;
import com.lti.hackathon.exam.portal.service.AdminAndStudentLoginValidationService;

@RestController
@CrossOrigin
public class AdminAndStudentLoginController {

	@Autowired
	private AdminAndStudentLoginValidationService adminAndStudentLoginValidationService;

	@RequestMapping(path = "/verify", method = RequestMethod.POST)
	public LoginResult login(@RequestBody RegisterStudent registerStudent) {
		LoginResult result = adminAndStudentLoginValidationService.verify(registerStudent);

		return result;
	}

}
