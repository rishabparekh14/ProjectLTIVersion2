package com.lti.hackathon.exam.portal.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.hackathon.exam.portal.Dao.QuestionOperationsDao;
import com.lti.hackathon.exam.portal.entity.QuestionBank;

@Service
public class QuestionOperationsService {

	@Autowired
	private QuestionOperationsDao questionOperationsDao;

	@Transactional
	public List<QuestionBank> fetch(String domain, int level) {
		return questionOperationsDao.fetchQuestionsByDomainAndLevel(domain, level);
	}

	@Transactional
	public void addQuestions(QuestionBank questionBank) {
		questionOperationsDao.addQuestion(questionBank);
	}
}
