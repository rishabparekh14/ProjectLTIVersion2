package com.lti.hackathon.exam.portal.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.hackathon.exam.portal.Dao.CandidateStatusDao;
import com.lti.hackathon.exam.portal.entity.CandidateTestStatus;

@Service
public class CandidateStatusService {

	@Autowired
	private CandidateStatusDao candidateStatusDao;

	@Transactional
	public long getScore(String emailAddress, int stage) {
		return candidateStatusDao.generateScore(emailAddress, stage);
	}

	@Transactional
	public String addCandidateAnswers(CandidateTestStatus candidateTestStatus) {
		candidateStatusDao.addCandidateAnswers(candidateTestStatus);
		return "Test has been submitted";
	}
}
