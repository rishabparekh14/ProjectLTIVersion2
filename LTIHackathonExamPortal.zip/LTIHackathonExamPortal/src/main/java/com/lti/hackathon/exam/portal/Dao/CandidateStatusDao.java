package com.lti.hackathon.exam.portal.Dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.hackathon.exam.portal.entity.CandidateTestStatus;

@Repository
public class CandidateStatusDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public void addCandidateAnswers(CandidateTestStatus candidateTestStatus) {
		entityManager.persist(candidateTestStatus);
	}

	@Transactional
	public long generateScore(String emailAddress, int stage) {
		System.out.println(emailAddress);
		System.out.println(stage);
		Query q = entityManager.createQuery(
				"select count (score) from CandidateTestStatus as score,OptionList as ol where score.emailAddress=:emailAddress and score.stage=:stage and ol.correctAnswer=:correctAnswer and ol.optionId=score.optionId");
		q.setParameter("emailAddress", emailAddress);
		q.setParameter("correctAnswer", "T");
		q.setParameter("stage", stage);

		return (long) q.getSingleResult();
	}

}
